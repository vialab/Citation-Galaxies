import entities.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.awt.print.Paper;
import java.io.File;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Properties;

public class Main {
    private static final int maxThreads = 5;
    private static EntityManager em;
    private static ArrayList<PaperFactory> paperFactories;


    public static void main(String[] args) throws Exception {
        paperFactories = new ArrayList<>();
        //Change this to your folder of files
        fileFinder("/home/kevin/Documents/ViaLab/Projects/Pablo/Papers/official-data/");
    }

    public static void fileFinder(String path) {
        File file = new File(path);
        if (file.isDirectory()) {
            for (File i : file.listFiles()) {
                fileFinder(i.toString());
            }
        } else {
            if (file.toString().substring(file.toString().length() - 4, file.toString().length()).equals("nxml")) {
                try {
                    int i = 0;
                    while (paperFactories.size() >= maxThreads) {
                        if (i > paperFactories.size() - 1) i = 0;
                        if (paperFactories.get(i).isAlive() == false) {
                            paperFactories.remove(paperFactories.get(i));
                        }
                        i++;
                    }
                    paperFactories.add(new PaperFactory(path));
                    paperFactories.get(paperFactories.size() - 1).start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }


}
