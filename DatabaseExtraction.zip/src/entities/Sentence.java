package entities;

import javax.persistence.*;

@Entity
public class Sentence {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int sentenceNum;

    private int startLocationPaper;
    private int endLocationPaper;
    private int startLocationPara;
    private int endLocationPara;

    @ManyToOne
    private Paragraph para;

    public Sentence() {
    }

    public Sentence(int sentenceNum, int startLocationPaper, int endLocationPaper, int startLocationPara, int endLocationPara, Paragraph para) {
        this.sentenceNum = sentenceNum;
        this.startLocationPaper = startLocationPaper;
        this.endLocationPaper = endLocationPaper;
        this.startLocationPara = startLocationPara;
        this.endLocationPara = endLocationPara;
        this.para = para;
    }

    public int getStartLocationPaper() {
        return startLocationPaper;
    }

    public void setStartLocationPaper(int startLocationPaper) {
        this.startLocationPaper = startLocationPaper;
    }

    public int getEndLocationPaper() {
        return endLocationPaper;
    }

    public void setEndLocationPaper(int endLocationPaper) {
        this.endLocationPaper = endLocationPaper;
    }

    public Paragraph getPara() {
        return para;
    }

    public void setPara(Paragraph para) {
        this.para = para;
    }

    public Integer getSentenceNum() {
        return sentenceNum;
    }

    public void setSentenceNum(int sentenceNum) {
        this.sentenceNum = sentenceNum;
    }

    public int getEndLocationPara() {
        return endLocationPara;
    }

    public void setEndLocationPara(int endLocationPara) {
        this.endLocationPara = endLocationPara;
    }

    public int getStartLocationPara() {
        return startLocationPara;
    }

    public void setStartLocationPara(int startLocationPara) {
        this.startLocationPara = startLocationPara;
    }
}