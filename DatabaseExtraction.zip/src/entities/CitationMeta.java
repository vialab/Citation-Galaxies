package entities;

import javax.persistence.*;

@Entity
public class CitationMeta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(length=1000000)
    private String authors;
    @Column(length=1000000)
    private String year;
    @Column(length=1000000)
    private String articleTitle;

    private int citationNumPaper;

    public CitationMeta() {
    }

    public CitationMeta(String authors , String year, String articleTitle, int citationNumPaper) {
        this.authors = authors;
        this.year = year;
        this.articleTitle = articleTitle;
        this.citationNumPaper = citationNumPaper;
    }

    public int getCitationNumPaper() {
        return citationNumPaper;
    }
}