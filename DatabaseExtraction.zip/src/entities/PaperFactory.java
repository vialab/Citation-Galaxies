package entities;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.ling.SentenceUtils;
import edu.stanford.nlp.pipeline.Annotation;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import edu.stanford.nlp.process.CoreLabelTokenFactory;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.process.PTBTokenizer;
import edu.stanford.nlp.process.WordToSentenceProcessor;
import edu.stanford.nlp.util.CoreMap;
import org.apache.xpath.operations.Bool;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

public class PaperFactory extends Thread {
    private static String jatsLocation = System.getProperty("user.dir") + "/JATS/";

    private String filePath;
    private EntityManager em;

    private Article article;
    private ArrayList<CitationMeta> citationsMetadata;
    private ArrayList<Citation> citations;
    private ArrayList<Paragraph> paragraphs;
    private ArrayList<Section> sections;
    private ArrayList<Sentence> sentences;
    private ArrayList<Word> words;

    public PaperFactory(String filePath) {
        this.filePath = filePath;
        this.citationsMetadata = new ArrayList<>();
        this.citations = new ArrayList<>();
        this.paragraphs = new ArrayList<>();
        this.sections = new ArrayList<>();
        this.sentences = new ArrayList<>();
        this.words = new ArrayList<>();

        //Properties props = new Properties();
        //EntityManagerFactory emf = Persistence.createEntityManagerFactory("verbs", props);
        //em = emf.createEntityManager();
    }

    public void run() {
        try {
            System.out.println(this.filePath.substring(this.filePath.lastIndexOf('/')+1, this.filePath.length()) + ": Collecting info");
            this.getMeta();
            System.out.println(this.filePath.substring(this.filePath.lastIndexOf('/')+1, this.filePath.length()) + ": Finished collecting info");
            //this.persist();
        } catch (Exception e) {
            System.err.println(this.filePath);
            e.printStackTrace();
        }
    }


    public void getMeta() throws Exception {
        String pmID = "";
        String articleTitle = "";
        String journalTitle = "";
        int articleYear = 0;

        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
        domFactory.setNamespaceAware(true);
        DocumentBuilder builder = domFactory.newDocumentBuilder();
        builder.setEntityResolver(new EntityResolver() {
            @Override
            public InputSource resolveEntity(String publicId, String systemId)
                    throws SAXException, IOException {
                String location = systemId;
                if (!systemId.contains("/JATS/")) {
                    location = jatsLocation + systemId.substring(systemId.lastIndexOf('/') + 1, systemId.length());
                }
                return new InputSource(location);
            }
        });
        XPathFactory xPathfactory = XPathFactory.newInstance();
        XPath xpath = xPathfactory.newXPath();
        Document file = builder.parse(this.filePath);


        //PMID and PMC search expressions
        XPathExpression pmidExp = xpath.compile("//front/article-meta/article-id[@pub-id-type='pmid']");
        XPathExpression pmcExp = xpath.compile("//front/article-meta/article-id[@pub-id-type='pmc']");

        //Search for PMID first, if not found get PMC and possibly parse it
        NodeList nl = (NodeList) pmidExp.evaluate(file, XPathConstants.NODESET);
        if (nl.getLength() == 0) {
            nl = (NodeList) pmcExp.evaluate(file, XPathConstants.NODESET);

            String tmp = nl.item(0).getTextContent();
            if (!tmp.substring(0, 3).equals("PMC")) {
                tmp = "PMC" + tmp;
            }
            pmID = tmp;
        } else {
            pmID = nl.item(0).getTextContent();
        }

        //Get the article title using an expression
        XPathExpression artitcleTitleExp = xpath.compile("//front/article-meta/title-group/article-title");
        articleTitle = ((NodeList) artitcleTitleExp.evaluate(file, XPathConstants.NODESET)).item(0).getTextContent();

        //Get the journal title using an expression
        XPathExpression journalTitleExp = xpath.compile("//front/journal-meta/journal-title-group/journal-title");
        journalTitle = ((NodeList) journalTitleExp.evaluate(file, XPathConstants.NODESET)).item(0).getTextContent();

        //Get the article year using an expression
        XPathExpression articleYearExp = xpath.compile("//front/article-meta/pub-date[@pub-type='pmc-release']/year");
        articleYear = Integer.parseInt(((NodeList) articleYearExp.evaluate(file, XPathConstants.NODESET)).item(0).getTextContent());


        //Get the paragraphs are parse them
        XPathExpression paragraphsExp = xpath.compile("//body/sec//p");
        nl = (NodeList) paragraphsExp.evaluate(file, XPathConstants.NODESET); //Use the pmid nodelist variable to save memory

        this.article = new Article(pmID, articleTitle, journalTitle, articleYear);

        Node parent = null; //Used to tell if its a section not a figure and for the section info
        Section currentSection = null; //Used to add the section to the paragraphs
        String paperText = ""; //Used to build all of the paragraphs
        int sectionStart = 0;
        for (int i = 0; i < nl.getLength(); i++) {
            NodeList currParagraph = nl.item(i).getChildNodes();

            String temp = ""; //Used to hold the individual paragraphs
            if (((Element) currParagraph).getParentNode().getNodeName().equals("sec")) {
                ArrayList<Citation> tmpCitations = new ArrayList<>(); //Used to hold the citations in the current paragraph

                //Get the sections and check if there isnt a new one
                if (parent != ((Element) currParagraph).getParentNode()) {
                    parent = ((Element) currParagraph).getParentNode();


                    String sectionTitle = "";
                    if (((Element) parent).getElementsByTagName("title").item(0) != null) {
                        sectionTitle = ((Element) parent).getElementsByTagName("title").item(0).getTextContent().replaceAll("  ", "").replaceAll("\\n", "");
                    }
                    String sectionID = "";
                    if (parent.getAttributes().getNamedItem("id") != null) {
                        sectionID = parent.getAttributes().getNamedItem("id").getNodeValue();
                    } else {
                        sectionID = Integer.toString(this.sections.size());
                    }

                    currentSection = new Section(sectionID, sectionTitle, -1, -1, this.article);
                }
                //Get and build the sentences for the paragraphs, recording the citation in each sentence
                int foundCitation = 0;
                char startBracket = 0;
                for (int j = 0; j < currParagraph.getLength(); j++) {
                    Node currNode = currParagraph.item(j); //The items inside the <p>
                    if (currNode.getNodeName().equals("xref") && currNode.getAttributes().item(0).getNodeValue().equals("bibr")) {

                        String citationID = ((Element) currNode).getAttribute("rid");

                        int startLocation = 0;
                        //Check if a other citation was found, if so use its start location
                        if (foundCitation > 0) {
                            startLocation = tmpCitations.get(tmpCitations.size() - 1).getStartLocationPara();
                        } else {
                            //Determine whether to use ( or [
                            if (temp.lastIndexOf('(') > temp.lastIndexOf('[')) {
                                startLocation = temp.lastIndexOf('(');
                                startBracket = temp.charAt(startLocation);
                            } else if (temp.lastIndexOf('(') < temp.lastIndexOf('[')) {
                                startLocation = temp.lastIndexOf('[');
                                startBracket = temp.charAt(startLocation);
                            }
                        }

                        //Create the new citation and only store the initial paragraph location
                        Citation tmpCitation = new Citation(citationID, this.article, startLocation, -1, null);

                        tmpCitations.add(tmpCitation);
                        foundCitation += 1;
                        temp += citationID;
                    } else {
                        //If [ or ( found use the closing bracket
                        if (startBracket == '(') {
                            startBracket = ')';
                        } else if (startBracket == '[') {
                            startBracket = ']';
                        }

                        //Check if the end of the citation has the closing bracket, if so then that is the end of the citation
                        if (foundCitation > 0 && currNode.getTextContent().replaceAll("  ", "").replaceAll("\\n", "").contains(Character.toString(startBracket))) {
                            for (int c = tmpCitations.size() - 1; c > tmpCitations.size() - 1 - foundCitation; c--) {
                                tmpCitations.get(c).setEndLocationPara(temp.length());
                            }
                            foundCitation = 0;
                        }
                        //Add the next chunk of text to the paragraph
                        temp += currNode.getTextContent().replaceAll("  ", "").replaceAll("\\n", "");
                    }
                }

                //Get paragraph locations and update the start of the section if its invalid
                //Always update the section end
                int startLocPara = paperText.length();
                int endLocPara = startLocPara - 1 + temp.length();

                if (currentSection.getStartLocationPaper() == -1) {
                    currentSection.setStartLocationPaper(startLocPara);
                }
                this.paragraphs.add(new Paragraph(startLocPara, endLocPara, currentSection, endLocPara - startLocPara + 1, this.article));
                for (Citation tc : tmpCitations) {
                    //Sets the citations locations and the paragraph ID
                    tc.setStartLocationPaper(paperText.length() + tc.getStartLocationPara());
                    tc.setEndLocationPaper(paperText.length() + tc.getEndLocationPara());
                    tc.setParagraphID(this.paragraphs.get(this.paragraphs.size() - 1));
                    this.citations.add(tc);
                }
                currentSection.setEndLocationPaper(endLocPara);

            }

            if (!this.sections.contains(currentSection)) {
                this.sections.add(currentSection);
            }
            paperText += temp;

        }

        this.article.setPaperText(paperText);

        //USED TO CHECK IF THE PARAGRAPHS HAVE PROPER BOUNDARIES
        //for (Citation p : this.citations) {
        //    System.out.println(this.article.getPaperText().substring(p.getStartLocationPaper(), p.getEndLocationPaper() + 1));
        //}

        //Get citation information
        XPathExpression refListExp = xpath.compile("//back/ref-list/ref");
        NodeList refList = (NodeList) refListExp.evaluate(file, XPathConstants.NODESET);
        citationsMetadata = new ArrayList<>();

        for (int l = 0; l < refList.getLength(); l++) {
            String metaYear = "";
            String metaArticleTitle = "";
            String authors = "";
            int num = 0;

            Node element = refList.item(l);

            //Get the references
            NodeList refData = element.getChildNodes();
            for (int i = 0; i < refData.getLength(); i++) {
                //Get the citation element in the references
                if (refData.item(i).getNodeName().contains("citation")) {
                    num = Integer.parseInt(refData.item(i).getParentNode().getAttributes().item(0).getTextContent().replaceAll("\\D+", ""));
                    refData = refData.item(i).getChildNodes();
                    break;
                }
            }

            //For year,article-title, or person-group loop and set the values
            for (int i = 0; i < refData.getLength(); i++) {
                if (refData.item(i).getNodeName() == "year") {
                    metaYear = refData.item(i).getTextContent();
                } else if (refData.item(i).getNodeName() == "article-title") {
                    metaArticleTitle = refData.item(i).getTextContent();
                } else if (refData.item(i).getNodeName() == "person-group") {
                    //Loop through the names, then the surname/given name and add it to the author strings
                    String surname = "";
                    String givenName = "";
                    authors = "";

                    NodeList personGroup = refData.item(i).getChildNodes();
                    for (int j = 0; j < personGroup.getLength(); j++) {
                        NodeList names = personGroup.item(j).getChildNodes();
                        for (int k = 0; k < names.getLength(); k++) {
                            if (names.item(k).getNodeName() == "surname") {
                                surname = names.item(k).getTextContent();
                            } else if (names.item(k).getNodeName() == "given-names") {
                                givenName = names.item(k).getTextContent();
                            }
                        }

                        authors += givenName + " " + surname + ", ";
                    }
                    //Remove the last comma
                    authors = authors.substring(0, authors.lastIndexOf(',') - 1);
                }
            }

            citationsMetadata.add(new CitationMeta(authors, metaYear, metaArticleTitle, num));
        }


        for (Citation c : this.citations) {
            for (CitationMeta cm : this.citationsMetadata) {
                if (Integer.parseInt(c.getCitationID().replaceAll("\\D+", "")) - 1 == cm.getCitationNumPaper()) {
                    c.setCitationMeta(cm);
                    break;
                }
            }

        }


        paraToSentence(this.article.getPaperText());
        //for (Word p : this.words) {
        //    System.out.println(this.article.getPaperText().substring(p.getStartLocationPaper(), p.getEndLocationPaper() + 1));
        //    System.out.println();
        //}
        //System.out.println();
    }


    public void paraToSentence(String paragraphs) {
        for (Paragraph p : this.paragraphs) {
            String paragraph = this.article.getPaperText().substring(p.getStartLocationPaper(), p.getEndLocationPaper() + 1);

            List<String> sentenceList;

            List<CoreLabel> tokens = new ArrayList<CoreLabel>(); //used to hold the "tokens" - each word from the paragraph
            PTBTokenizer<CoreLabel> tokenizer = new PTBTokenizer<CoreLabel>(new StringReader(paragraph), new CoreLabelTokenFactory(), "");
            while (tokenizer.hasNext()) {
                tokens.add(tokenizer.next());
            }

            //Splits the sentences using the tokens
            List<List<CoreLabel>> sentences = new WordToSentenceProcessor<CoreLabel>().process(tokens);

            //Used to put the tokens back together
            int end;
            int start = 0;
            sentenceList = new ArrayList<String>();

            //Constructs the original sentence using the original words
            //Does this by finding the location of the last char in the sentence created, and grabbing the chunk of
            //- text from the original string

            ArrayList<Sentence> tmpSentences = new ArrayList<>();
            for (List<CoreLabel> sentence : sentences) {
                end = sentence.get(sentence.size() - 1).endPosition();
                sentenceList.add(paragraph.substring(start, end));

                end--;
                //Subtract 1 from the end so that the location is proper
                tmpSentences.add(new Sentence(0, start + p.getStartLocationPaper(), end + p.getStartLocationPaper(), start, end, p));
                end++;

                /*for (Citation cit : this.citations) {
                    if (cit.getStartLocationPaper() >= start && cit.getEndLocationPaper() <= end) {
                        cit.setSentenceNum(this.sentences.get(this.sentences.size() - 1));
                    }
                }*/

                start = end;
            }

            //A fix for citations being split on two lines, checks if a new line starts with a citation reference and joins the sentence to one the previous
            Boolean joined = false;
            for (int i = 0; i < tmpSentences.size(); i++) {
                for (Citation c : this.citations) {
                    if (this.article.getPaperText().substring(tmpSentences.get(i).getStartLocationPaper(),
                            tmpSentences.get(i).getStartLocationPaper() + c.getCitationID().length() + 1).contains(c.getCitationID())) {
                        Sentence tmp = this.sentences.get(this.sentences.size() - 1);
                        tmp.setEndLocationPaper(tmpSentences.get(i).getEndLocationPaper());
                        tmp.setEndLocationPara(tmpSentences.get(i).getEndLocationPara());
                        joined = true;
                        break;
                    }


                }
                if (joined == false) {
                    this.sentences.add(tmpSentences.get(i));
                } else {
                    joined = false;
                }
            }
        }

        //Get the citation's sentence and update the paragraph sentence count
        int j = 1; //Used to hold the sentence number
        Paragraph currParagraph = this.paragraphs.get(0);
        for (Sentence s : this.sentences) {
            if (s.getPara() != currParagraph) {
                currParagraph.setSentenceCount(j - 1);
                j = 1;
                currParagraph = s.getPara();
            }

            for (Citation c : this.citations) {
                if (c.getStartLocationPaper() >= s.getStartLocationPaper()) {
                    if (c.getEndLocationPaper() <= s.getEndLocationPaper()) {
                        c.setSentence(s);
                    }
                }
            }
            s.setSentenceNum(j);
            j++;
        }

        //for (Citation p : this.citations) {
        //    System.out.println(this.article.getPaperText().substring(p.getStartLocationPaper(), p.getEndLocationPaper() + 1));
        //}
        //Used to call the word generator
        for (Paragraph p : this.paragraphs) {
            for (Citation c : this.citations) {
                if (c.getParagraphID() == p) {
                    Boolean otherCitationFoundAbove = false; //Used to stop if another citation is found
                    Boolean otherCitationFoundBelow = false;

                    //Get the current sentence the citation is on
                    Sentence tmpSentence = c.getSentence();
                    //LOOK HERE, MIGHT BE ISSUES WITH ASSIGNING SENTENCE NUMBERS
                    if (tmpSentence.getSentenceNum() != null) {
                        int above = tmpSentence.getSentenceNum() - 1; //Get the sentence number above and below the current one
                        int below = tmpSentence.getSentenceNum() + 1;

                        //Get the words for the current sentence
                        sentenceToWords(this.article.getPaperText().substring(tmpSentence.getStartLocationPaper(), tmpSentence.getEndLocationPaper() + 1), tmpSentence, c);


                        //Loop going up sentences until either a sentence with a citation is found or we hit the beginning of the paragraph
                        while (!otherCitationFoundAbove && above > 0) {
                            Sentence aboveSentence = null;
                            for (Sentence s : this.sentences) {
                                if (!otherCitationFoundAbove && s.getPara() == c.getParagraphID() && s.getSentenceNum() == above) {
                                    for (Citation ct : this.citations) {
                                        if (ct != c && c.getSentence() == s) {
                                            otherCitationFoundAbove = true;
                                            break;
                                        }
                                    }
                                    aboveSentence = s;
                                    break;
                                }
                            }

                            if (!otherCitationFoundAbove) {
                                sentenceToWords(this.article.getPaperText().substring(aboveSentence.getStartLocationPaper(), aboveSentence.getEndLocationPaper() + 1), aboveSentence, c);
                            }
                            above -= 1;
                        }

                        //Loop going down sentences until either a sentence with a citation is found or we hit the end of the paragraph
                        while (!otherCitationFoundBelow && below <= c.getParagraphID().getSentenceCount()) {
                            Sentence belowSentence = null;

                            for (Sentence s : this.sentences) {
                                if (!otherCitationFoundBelow && s.getPara() == c.getParagraphID() && s.getSentenceNum() == below) {
                                    for (Citation ct : this.citations) {
                                        if (ct != c && c.getSentence() == s) {
                                            otherCitationFoundBelow = true;
                                            break;
                                        }
                                    }
                                    belowSentence = s;
                                    break;
                                }
                            }

                            if (!otherCitationFoundBelow) {
                                sentenceToWords(this.article.getPaperText().substring(belowSentence.getStartLocationPaper(), belowSentence.getEndLocationPaper() + 1), belowSentence, c);
                            }
                            below += 1;
                        }
                    }
                }
            }
        }
    }


    public void sentenceToWords(String sentence, Sentence sen, Citation cit) {
        List<String> wordList;

        List<CoreLabel> tokens = new ArrayList<CoreLabel>(); //used to hold the "tokens" - each word from the paragraph
        PTBTokenizer<CoreLabel> tokenizer = new PTBTokenizer<CoreLabel>(new StringReader(sentence), new CoreLabelTokenFactory(), "");
        while (tokenizer.hasNext()) {
            tokens.add(tokenizer.next());
        }

        //Splits the sentences using the tokens

        //Used to put the tokens back together
        int end;
        int start = 0;
        wordList = new ArrayList<String>();

        //Constructs the original sentence using the original words
        //Does this by finding the location of the last char in the sentence created, and grabbing the chunk of
        //text from the original string
        for (CoreLabel word : tokens) {
            end = word.endPosition();
            String tmp = sentence.substring(start, end);

            end--;
            wordList.add(tmp);
            this.words.add(new Word(tmp, cit, start + sen.getStartLocationPaper(), end + sen.getStartLocationPaper(), start + sen.getStartLocationPara(), end + sen.getStartLocationPaper(), sen, sen.getPara()));
            end++;
            start = end;

        }
    }


    public void persist() {
        System.out.println(this.filePath.substring(this.filePath.lastIndexOf('/')+1, this.filePath.length()) + ": Adding files to database...");
        em.getTransaction().begin();
        em.persist(article);
        for (CitationMeta cm : citationsMetadata) {
            em.persist(cm);
        }
        for (Citation c : citations) {
            em.persist(c);
        }
        for (Paragraph p : paragraphs) {
            em.persist(p);
        }
        for (Section s : sections) {
            em.persist(s);
        }
        for (Sentence s : sentences) {
            em.persist(s);
        }
        for (Word w : words) {
            em.persist(w);
        }
        em.getTransaction().commit();
        System.out.println(this.filePath.substring(this.filePath.lastIndexOf('/')+1, this.filePath.length()) + ": Finished adding files to the database");
    }
}
