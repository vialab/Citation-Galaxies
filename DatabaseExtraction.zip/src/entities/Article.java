package entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.*;

@Entity
public class Article {
    @Id
    private String id;
    @Column(length=1000000)
    private String articleTitle;
    @Column(length=1000000)
    private String journalTitle;
    private int articleYear;
    @Column(length=10485760)
    private String paperText;
    private int charCount;

    public Article() {
    }

    public Article(String pmid, String articleTitle, String journalTitle, int articleYear) {
        this.id = pmid;
        this.articleTitle = articleTitle;
        this.journalTitle = journalTitle;
        this.articleYear = articleYear;

    }

    public String getPaperText() {
        return paperText;
    }

    public void setPaperText(String text){
        this.paperText = text;
        this.charCount = paperText.length();
    }
}
