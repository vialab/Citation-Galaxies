package entities;

import javax.persistence.*;

@Entity
public class Paragraph {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int sentenceCount;
    private int startLocationPaper;
    private int endLocationPaper;

    private int charCount;
    @ManyToOne
    Article articleId;
    @ManyToOne
    Section sectionID;

    public Paragraph() {
    }

    public Paragraph(int startLocationPaper, int endLocationPaper, Section sectionID, int charCount, Article articleId) {
        this.startLocationPaper = startLocationPaper;
        this.endLocationPaper = endLocationPaper;
        this.sectionID = sectionID;
        this.charCount = charCount;
        this.articleId = articleId;
    }

    public Paragraph(int sentenceCount, int startLocationPaper, int endLocationPaper, Section section, int charCount, Article articleId) {
        this.sentenceCount = sentenceCount;
        this.startLocationPaper = startLocationPaper;
        this.endLocationPaper = endLocationPaper;
        this.sectionID = sectionID;
        this.charCount = charCount;
        this.articleId = articleId;
    }

    public int getEndLocationPaper() {
        return endLocationPaper;
    }

    public void setEndLocationPaper(int endLocationPaper) {
        this.endLocationPaper = endLocationPaper;
    }

    public int getStartLocationPaper() {
        return startLocationPaper;
    }

    public void setStartLocationPaper(int startLocationPaper) {
        this.startLocationPaper = startLocationPaper;
    }

    public int getCharCount() {
        return charCount;
    }

    public void setCharCount(int charCount) {
        this.charCount = charCount;
    }

    public int getSentenceCount() {
        return sentenceCount;
    }

    public void setSentenceCount(int sentenceCount) {
        this.sentenceCount = sentenceCount;
    }
}