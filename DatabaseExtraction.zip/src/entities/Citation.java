package entities;

import javax.persistence.*;

@Entity
public class Citation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(length=10485760)
    private String citationID;
    @ManyToOne
    Article articleID;
    @ManyToOne
    CitationMeta citationMeta;
    @ManyToOne
    private Paragraph paragraphID;
    private int startLocationPara;
    private int startLocationPaper;
    private int endLocationPara;
    private int endLocationPaper;

    @OneToOne
    private Sentence sentence;

    public Citation() {
    }

    public Citation(String citationID, Article articleID, int startLocationPara,
                    int startLocationPaper, Paragraph paragraphID) {
        this.citationID = citationID;
        this.articleID = articleID;
        this.startLocationPara = startLocationPara;
        this.startLocationPaper = startLocationPaper;
        this.paragraphID = paragraphID;
    }

    public Sentence getSentenc() {
        return sentence;
    }

    public void setCitationMeta(CitationMeta cm) {
        this.citationMeta = cm;
    }

    public String getCitationID() {
        return citationID;
    }

    public int getStartLocationPara() {
        return startLocationPara;
    }

    public int getStartLocationPaper() {
        return startLocationPaper;
    }

    public void setStartLocationPaper(int startLocationPaper) {
        this.startLocationPaper = startLocationPaper;
    }

    public Paragraph getParagraphID() {
        return paragraphID;
    }

    public int getEndLocationPara() {
        return endLocationPara;
    }

    public Sentence getSentence() {
        return this.sentence;
    }

    public void setSentence(Sentence sentence) {
        this.sentence = sentence;
    }


    public void setEndLocationPara(int endLocationPara) {
        this.endLocationPara = endLocationPara;
    }

    public int getEndLocationPaper() {
        return endLocationPaper;
    }

    public void setEndLocationPaper(int endLocationPaper) {
        this.endLocationPaper = endLocationPaper;
    }

    public void setParagraphID(Paragraph paragraphID) {
        this.paragraphID = paragraphID;
    }
}