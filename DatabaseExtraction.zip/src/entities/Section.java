package entities;

import javax.persistence.*;

@Entity
public class Section {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String sectionID;
    private String sectionTitle;
    private int startLocationPaper;
    private int endLocationPaper;
    @ManyToOne
    Article articleID;

    public Section() {
    }

    public Section(String sectionID, String sectionTitle, int startLocationPaper, int endLocationPaper, Article articleID) {
        this.sectionID = sectionID;
        this.sectionTitle = sectionTitle;
        this.startLocationPaper = startLocationPaper;
        this.endLocationPaper = endLocationPaper;
        this.articleID = articleID;

    }

    public int getStartLocationPaper() {
        return startLocationPaper;
    }

    public void setStartLocationPaper(int startLocationPaper) {
        this.startLocationPaper = startLocationPaper;
    }

    public int getEndLocationPaper() {
        return endLocationPaper;
    }

    public void setEndLocationPaper(int endLocationPaper) {
        this.endLocationPaper = endLocationPaper;
    }

    public String getSectionTitle() {
        return sectionTitle;
    }

    public void setSectionTitle(String sectionTitle) {
        this.sectionTitle = sectionTitle;
    }
}