package entities;

import javax.persistence.*;

@Entity
public class Word {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(length=10485760)
    private String term;
    @Column(length=10485760)
    private String lemma;
    private int startLocationPaper;
    private int endLocationPaper;
    private int startLocationPara;
    private int endLocationPara;

    @OneToOne
    private Sentence sentence;

    @ManyToOne
    private Citation citationID;

    @ManyToOne
    private Paragraph paragraphID;

    public Word() {
    }

    public Word(String term, Citation citationID, int startLocationPaper, int endLocationPaper, int startLocationPara,
                int endLocationPara, Sentence sentence, Paragraph paragraphID) {
        this.term = term;
        this.citationID = citationID;
        this.startLocationPaper = startLocationPaper;
        this.endLocationPaper = endLocationPaper;
        this.startLocationPara = startLocationPara;
        this.endLocationPara = endLocationPara;
        this.sentence = sentence;
        this.paragraphID = paragraphID;
    }

    public String getTerm() {
        return term;
    }

    public int getStartLocationPaper() {
        return startLocationPaper;
    }

    public int getEndLocationPaper() {
        return endLocationPaper;
    }

    public int getStartLocationPara() {
        return startLocationPara;
    }

    public int getEndLocationPara() {
        return endLocationPara;
    }

    public Citation getCitationID() {
        return citationID;
    }

    public void setCitationID(Citation citationID) {
        this.citationID = citationID;
    }
}